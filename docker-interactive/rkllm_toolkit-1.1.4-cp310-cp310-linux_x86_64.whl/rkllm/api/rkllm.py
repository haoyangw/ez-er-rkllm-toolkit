from rkllm.api.rkllm_base import RKLLMBase

class RKLLM:
    def __init__(self, v=''):
        self.base = RKLLMBase(v)

    def load_huggingface(self, model, model_lora=None, device='cpu'):
        """
        Load huggingface model
        :param model: base model path
        :param model_lora: lora model path
        :param device: cuda or cpu
        :return: success: 0, failure: -1
        """
        ret = self.base.load_huggingface(model, model_lora, device)
        return ret

    def load_gguf(self, model):
        """
        Load gguf model
        :param model_path: gguf model path
        :return: success: 0, failure: -1
        """
        ret = self.base.load_gguf(model)
        return ret

    def update_rkllm(self, model):
        """
        Update rkllm model
        :param model_path: rkllm model path
        :return: success: 0, failure: -1
        """
        ret = self.base.update_rkllm(model)
        return ret

    def build(self, do_quantization=True, optimization_level=1, quantized_dtype='w8a8', quantized_algorithm='normal', target_platform='rk3588', num_npu_core=3, extra_qparams=None, dataset=None, hybrid_rate=0):
        """
        Build model
        :param do_quantization: Need do quantization
        :param optimization_level: 1 do optimization, 0 not
        :param quantized_dtype: quantization type, options: [w4a16, w4a16_g32, w4a16_g64, w4a16_g128, w8a8, w8a8_g128, w8a8_g256, w8a8_g512]
        :param quantized_algorithm: quantization algorithm, options: [normal, gdq], gdq only supports 4bit quantization
        :param target_platform: platform type, options: [rk3588, rk3576]
        :param num_npu_core: number of npu core required, options: rk3588 is [1,2,3], rk3576 is [1,2]
        :param extra_qparams: user-provided quantization parameters or the quantization parameters cached by gdq quantized_algorithm[gdq.qparams]
        :param dataset: the path to the dataset for calibration, in json format: 
            1、when the input is text: [{"input":"", "target": ""},...]
            2、when the input is inputs_embeds: [{"input_embed":""},...]
        :param hybrid_rate: block(group-wise quantization) ratio, whose value is between 0 and 1, 0 indicating the disable of mixed quantization
        :return: success: 0, failure: -1
        """
        ret = self.base.build(do_quantization, optimization_level, quantized_dtype, quantized_algorithm, target_platform, num_npu_core, extra_qparams, dataset, hybrid_rate)
        return ret

    def export_rkllm(self, export_path):
        """
        Export rknn model to file
        :param export_path: Export rkllm model path
        :return: success: 0, failure: -1
        """
        ret = self.base.export_rkllm(export_path)
        return ret

    def eval_accuracy(self, seqlen=512, dataset='wikitext'):
        """
        Evaluate model accuracy
        :param seqlen: the length of input
        :param dataset: the name of dataset
        :return: success: 0, failure: -1
        """
        ret = self.base.eval_accuracy(seqlen, dataset)
        return ret

    def chat_model(self, messages, args):
        """
        Return text
        :param messages: input text, the text needs to add prompt words
        :param args: inference configuration parameters, such as top-k and other sampling strategy parameters
        :return: success: text, failure: None
        """
        return self.base.chat_model(messages, args)

    def get_logits(self, inputs):
        """
        Return logits
        :param inputs: {"input_ids":"",}, just like the method of calling models in huggingface
        :return: success: logits, failure: None
        """
        ret = self.base.get_logits(inputs)
        return ret